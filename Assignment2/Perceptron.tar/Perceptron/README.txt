
Assignment 2 Part B:

 Cameron Palk
 Feb 6th 2016
 CIS 472



== Perceptron ==

Written in Python 3

In directory Perceptron/
Run with:
	python3 perceptron.py <training data> <testing data> <output file>

Max iteration is 100 but lower iteration counts ( ex. 50 iterations ) gets better accuracy.
