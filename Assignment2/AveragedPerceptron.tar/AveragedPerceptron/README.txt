
Assignment 2 Part B Extra Credit:

 Cameron Palk
 Feb 6th 2016
 CIS 472


== Averaged Weights and Randomized Subset TrainingPerceptron == 

In directory AveragedPerceptron/
Run with:
	python3 averagedPerceptron.py <training data> <testing data> <output file>
