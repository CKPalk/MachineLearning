

Assignment 1 Part B - ID3 Algorithm 
_____________________________________

Name: 	 	Cameron Palk
Partner: 	Joel Benner
Language: 	Python 3.5

Run it with:

	python3 id3.py <training-set> <test-set> <model-file>


